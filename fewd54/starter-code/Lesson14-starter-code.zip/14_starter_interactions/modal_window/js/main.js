// Write your pseudo code here! HAPPY CODING!!
