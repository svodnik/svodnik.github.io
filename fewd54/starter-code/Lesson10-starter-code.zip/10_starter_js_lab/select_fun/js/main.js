
jQuery('.box').addClass('fun');

$('#box2').on('click', function () {
	$('h1').addClass('crazy');
	$('.box').removeClass('crazy')
	$('#box3').slideToggle();
});

$('.box').on('click', function () {
	$('header').find('h1').html('jQuery Ninja');
});

$('#box1').on('click', function () {
	$(".moto").attr("src", "images/moto.jpg");
});

$('#dropdownMenu').hide();

$('#dropdownButton').on('click', function () {
	$('#dropdownMenu').slideToggle();
});

$('#answer2').hide();

$('#answer1').show();

$('#question2').on('click', function () {
	$('#answer2').slideDown();
	$('#answer1').slideUp();
	$('li').removeClass('active');
	$('#question2').addClass('active');
});

$('#question1').on('click', function () {
	$('#answer1').slideDown();
	$('#answer2').slideUp();
	$('li').removeClass('active');
	$('#question1').addClass('active');
});