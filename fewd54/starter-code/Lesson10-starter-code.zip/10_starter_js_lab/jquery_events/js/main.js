// TOGETHER: Let's take a look at this example:
// 1. When the user releases a key on the input element
// HINT: Event type: keyup   Selector: The input element
	// a) Add the class correct to the input



// 1. Look up the prepend and append methods in the jQuery documentation.
// When the user's mouse enters #trigger
// HINT: Event type: mouseenter 
	// a) Add a <li> to the beginning of #myList that contains the text "1"
	// b) Add a <li> to the end of #myList that contains the text "5"


// 2.	When the browser window is resized
// HINT: Event type: resize   Selector: $(window) with no quotes
	// a) fade in .circle-two
$(window).on('enterTheEventTypeHere', function () {

});

// BONUS: When the user scrolls down the page
// HINT: Event type: resize   Selector: $(window) with no quotes
	// a) Add the .party class to the body
$(window).on('enterTheEventTypeHere', function () {

});

// EXTRA BONUS (No hints!):
// 1) Follow step 1 in style.css (near the bottom of the document)
// 2) When the user clicks on the button
	// a) TOGGLE the class .highlight to the element with the class .square